import java.util.Scanner;

public class StudentManagement {
    public static void main(String[] args) {
        // 학생 수 입력 받기
        int numStudents = 5;

        // 학생 정보 입력 받기
        Scanner scanner = new Scanner(System.in);
        Student[] students = new Student[numStudents];
        for (int i = 0; i < numStudents; i++) {
            System.out.println("학생 정보를 입력하세요.");
            System.out.print("학번: ");
            String id = scanner.next();
            System.out.print("이름: ");
            String name = scanner.next();
            System.out.print("국어: ");
            int korean = scanner.nextInt();
            System.out.print("영어: ");
            int english = scanner.nextInt();
            System.out.print("수학: ");
            int math = scanner.nextInt();
            System.out.print("자바: ");
            int java = scanner.nextInt();
            students[i] = new Student(id, name, korean, english, math, java);
        }

        // 학생 정보 출력하기
        System.out.println("학번\t이름\t국어\t영어\t수학\t자바\t총점\t평균\t학점");
        for (Student student : students) {
            System.out.println(student.getId() + "\t" + student.getName() + "\t" + student.getKorean() +
                    "\t" + student.getEnglish() + "\t" + student.getMath() + "\t" + student.getJava() +
                    "\t" + student.getTotal() + "\t" + student.getAverage() + "\t" + student.getGrade());
        }
    }
}

class Student {
    private String id;
    private String name;
    private int korean;
    private int english;
    private int math;
    private int java;

    public Student(String id, String name, int korean, int english, int math, int java) {
        this.id = id;
        this.name = name;
        this.korean = korean;
        this.english = english;
        this.math = math;
        this.java = java;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getKorean() {
        return korean;
    }

    public int getEnglish() {
        return english;
    }

    public int getMath() {
        return math;
    }

    public int getJava() {
        return java;
    }

    public int getTotal() {
        return korean + english + math + java;
    }

    public double getAverage() {
        return (double) getTotal() / 4;
    }

    public String getGrade() {
        double average = getAverage();
        if (average >= 90) {
            return "A";
        } else if (average >= 80) {
            return "B";
        } else if (average >= 70) {
            return "C";
        } else if (average >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
}
