public class exam01 {
    public static void main(String args[]){
        System.out.println("안드로이드를 위한 Java 연습");
    }
}
