public class exam07 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Car myCar1 =new Car("빨강", 0);
        Car myCar2 = new Car("파랑",0);
        Car myCar3 = new Car("초록",0);


        myCar1.upSpeed(50);
        System.out.println("자동차1의 색상은 " + myCar1.getColor()
                +"이며, 속도는"
                +myCar1.getSpeed() + "km입니다.");

        myCar1.upSpeed(20);
        System.out.println("자동차1의 색상은 " + myCar1.getColor()
                +"이며, 속도는"
                +myCar1.getSpeed() + "km입니다.");

        myCar1.upSpeed(250);
        System.out.println("자동차1의 색상은 " + myCar1.getColor()
                +"이며, 속도는"
                +myCar1.getSpeed() + "km입니다.");
    }

}
