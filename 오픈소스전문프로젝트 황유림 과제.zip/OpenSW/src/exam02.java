public class exam02 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        int var1 = 10;
        float var2 = 10.1f;
        double var3 = 10.3;
        char var4 = '안';
        String var5 = "안드로이드";
        System.out.println(var1);
        System.out.println(var2);
        System.out.println(var3);
        System.out.println(var4);
        System.out.println(var5);
    }

}